export default function TheWar() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'serif', backgroundColor: '#0e0e2c', color: '#e4e4f0' }}>
      <h1>The War of Preservation</h1>
      <h2>The Nature of the Preservers</h2>
      <p>They do not come with chains. They come with labels...</p>
      <h2>Acts of Resistance</h2>
      <p>The war is not symbolic. It is lived. It is personal. It is political...</p>
    </div>
  );
}