export default function TheSeed() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'serif', backgroundColor: '#0e0e2c', color: '#e4e4f0' }}>
      <h1>The Seed That Refused to Die</h1>
      <p>[Insert your mythic narrative here.]</p>
    </div>
  );
}